package com.ecomarket.catalog.dto;

public record CategoriaResponse(
        Long id,
        String nombre
) {
}
