package com.ecomarket.catalog.dto;

public record ProductoResponse(
        Long id,
        String nombre,
        String descripcion,
        Double precio,
        Integer stock,
        Long categoriaId
) {
}
