package com.ecomarket.order.dto;

public record ProductoDTO(
        Long id,
        String nombre,
        String descripcion,
        Double precio,
        Integer stock,
        Long categoriaId
) {
}
