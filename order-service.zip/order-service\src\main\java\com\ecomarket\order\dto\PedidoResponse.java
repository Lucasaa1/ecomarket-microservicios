package com.ecomarket.order.dto;

import java.time.LocalDateTime;

public record PedidoResponse(
        Long id,
        Long usuarioId,
        Long productoId,
        String productoNombre,
        Integer cantidad,
        LocalDateTime fecha,
        String estado
) {
}
