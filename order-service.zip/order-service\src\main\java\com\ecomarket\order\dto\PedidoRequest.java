package com.ecomarket.order.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record PedidoRequest(
        @NotNull Long usuarioId,
        @NotNull Long productoId,
        @Min(1) Integer cantidad
) {
}
