package com.ecomarket.auth.dto;

public record LoginResponse(
        String token,
        String tipo,
        Long expiraEn,
        UsuarioResponse usuario
) {
}
